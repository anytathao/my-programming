import pandas as pd
import numpy as np
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(BASE_DIR / ".matplotlib-cache"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

COLUMN_MAP = {
    "Hour": "hour",
    "Cell_Count": "cell_count",
    "Viability_pct": "viability",
    "Average_Size_um": "cell_size",
}


def load_csv(path):
    return pd.read_csv(path)


# Functions

def clean_data(path):
    df = load_csv(path)
    df = df.rename(columns=COLUMN_MAP)
    df["culture"] = Path(path).stem
    return df


def average(values):
    total = 0

    for value in values:
        total = total + value

    return total / len(values)


def add_growth_info(df):
    growth_ratios = []
    rolling_growth_A1 = []
    rolling_growth_A2 = []
    viability_drop_B = []
    first_major_viability_drop_B = []
    size_jump_C = []
    found_first_drop = False

    for i in range(len(df)):
        if i == 0:
            growth_ratios.append(0)
            viability_drop_B.append(False)
            first_major_viability_drop_B.append(False)
            size_jump_C.append(False)
        else:
            last_count = df["cell_count"].iloc[i - 1]
            current_count = df["cell_count"].iloc[i]
            growth = (current_count - last_count) / last_count
            growth_ratios.append(growth)

            last_viability = df["viability"].iloc[i - 1]
            current_viability = df["viability"].iloc[i]
            viability_drop = current_viability < last_viability - 10
            viability_drop_B.append(viability_drop)

            if viability_drop and not found_first_drop:
                first_major_viability_drop_B.append(True)
                found_first_drop = True
            else:
                first_major_viability_drop_B.append(False)

            last_size = df["cell_size"].iloc[i - 1]
            current_size = df["cell_size"].iloc[i]
            size_change = abs(current_size - last_size) / last_size
            size_jump_C.append(size_change > 0.15)

        start_A1 = i - 2
        if start_A1 < 0:
            start_A1 = 0

        start_A2 = i - 4
        if start_A2 < 0:
            start_A2 = 0

        rolling_growth_A1.append(average(growth_ratios[start_A1:i + 1]))
        rolling_growth_A2.append(average(growth_ratios[start_A2:i + 1]))

    df["growth_ratio"] = growth_ratios
    df["rolling_growth_A1"] = rolling_growth_A1
    df["rolling_growth_A2"] = rolling_growth_A2
    df["viability_drop_B"] = viability_drop_B
    df["first_major_viability_drop_B"] = first_major_viability_drop_B
    df["size_jump_C"] = size_jump_C
    return df


def growth_metrics(df):
    metrics = {
        "average_cell_count": average(df["cell_count"]),
        "average_viability": average(df["viability"]),
        "average_cell_size": average(df["cell_size"]),
        "final_cell_count": df["cell_count"].iloc[len(df) - 1],
    }

    return metrics


def predict_next_count(df):
    changes = []
    start = len(df) - 3

    if start < 1:
        start = 1

    for i in range(start, len(df)):
        change = df["cell_count"].iloc[i] - df["cell_count"].iloc[i - 1]
        changes.append(change)

    prediction = df["cell_count"].iloc[len(df) - 1] + average(changes)
    return int(round(prediction))


def recommend_harvest_window(df):
    highest_count = df["cell_count"].max()
    target_count = highest_count * 0.85

    for i in range(len(df)):
        count = df["cell_count"].iloc[i]
        viability = df["viability"].iloc[i]

        if count >= target_count and viability >= 90:
            hour = df["hour"].iloc[i]
            return f"Hour {hour}: high count with viability >= 90%"

    best_hour = df["hour"].iloc[len(df) - 1]
    return f"Hour {best_hour}: highest count, but check viability"


def summarize_culture(df):
    summary = growth_metrics(df)
    summary["culture"] = df["culture"].iloc[0]
    summary["rolling_A1_mean"] = average(df["rolling_growth_A1"])
    summary["rolling_A2_mean"] = average(df["rolling_growth_A2"])
    summary["viability_drops"] = int(df["viability_drop_B"].sum())
    summary["first_major_drops"] = int(df["first_major_viability_drop_B"].sum())
    summary["size_jumps"] = int(df["size_jump_C"].sum())
    summary["predicted_next_count"] = predict_next_count(df)
    summary["harvest_window"] = recommend_harvest_window(df)
    summary["suspicious_events"] = summary["viability_drops"] + summary["size_jumps"]
    return summary


# Main

def main():
    # Phase 1: Load one culture and compute core metrics

    first_file = DATA_DIR / "culture_day_A.csv"

    if not first_file.exists():
        raise FileNotFoundError(f"No culture_day_A.csv files found in {DATA_DIR}")

    df = clean_data(first_file)
    df = add_growth_info(df)
    phase1_summary = growth_metrics(df)

    pd.DataFrame([phase1_summary]).to_csv(
        OUTPUT_DIR / "phase1_summary.csv", index=False
    )

    plt.figure()
    plt.plot(df["hour"], df["cell_count"])
    plt.xlabel("Hour")
    plt.ylabel("Cell Count")
    plt.title("Cell Count Over Time")
    plt.savefig(OUTPUT_DIR / "cell_count_plot.png")
    plt.close()

    plt.figure()
    plt.plot(df["hour"], df["viability"])
    plt.xlabel("Hour")
    plt.ylabel("Viability")
    plt.title("Viability Over Time")
    plt.savefig(OUTPUT_DIR / "viability_plot.png")
    plt.close()

    (OUTPUT_DIR / "phase1_reflection.md").write_text(
        "Phase 1 Reflection\n"
        "------------------\n"
        "The culture shows steady growth over time.\n"
        "Viability remains relatively stable.\n"
        "The dataset is suitable for comparison in later phases.\n",
        encoding="utf-8",
    )

    # Phase 2: Compare multiple cultures and variants

    culture_files = sorted(DATA_DIR.glob("culture_day_*.csv"))
    all_data = []
    summary_rows = []

    for culture_file in culture_files:
        culture_df = clean_data(culture_file)
        culture_df = add_growth_info(culture_df)

        all_data.append(culture_df)
        summary_rows.append(summarize_culture(culture_df))

    combined = pd.concat(all_data)
    phase2_summary = pd.DataFrame(summary_rows)
    phase2_summary = phase2_summary.sort_values("final_cell_count", ascending=False)

    phase2_summary.to_csv(OUTPUT_DIR / "phase2_summary.csv", index=False)

    plt.figure()
    plt.bar(phase2_summary["culture"], phase2_summary["final_cell_count"])
    plt.xlabel("Culture")
    plt.ylabel("Final Cell Count")
    plt.title("Final Cell Count Comparison")
    plt.savefig(OUTPUT_DIR / "cell_count_comparison.png")
    plt.close()

    notes = []
    for _, row in phase2_summary.iterrows():
        notes.append(
            f"{row['culture']}: "
            f"{int(row['viability_drops'])} viability drops, "
            f"{int(row['size_jumps'])} size jumps, "
            f"next count predicted at {int(row['predicted_next_count'])}. "
            f"Harvest recommendation: {row['harvest_window']}."
        )

    (OUTPUT_DIR / "phase2_notes.md").write_text(
        "Phase 2 Notes\n"
        "-------------\n" +
        "\n".join(notes),
        encoding="utf-8",
    )

    # Phase 3: Batch processing, dashboard, and report

    combined.to_csv(OUTPUT_DIR / "combined_culture_data.csv", index=False)

    first_culture = combined["culture"].iloc[0]
    one = combined[combined["culture"] == first_culture]

    plt.figure(figsize=(10, 8))

    plt.subplot(2, 2, 1)
    plt.plot(one["hour"], one["cell_count"])
    plt.title("Cell Count")

    plt.subplot(2, 2, 2)
    plt.plot(one["hour"], one["viability"])
    plt.title("Viability")

    plt.subplot(2, 2, 3)
    plt.plot(one["hour"], one["cell_size"])
    plt.title("Cell Size")

    plt.subplot(2, 2, 4)
    plt.bar(phase2_summary["culture"], phase2_summary["final_cell_count"])
    plt.title("Final Counts")

    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "culture_dashboard.png")
    plt.close()

    best = phase2_summary.iloc[0]["culture"]
    worst = phase2_summary.iloc[-1]["culture"]

    report_lines = [
        f"Strongest growth culture: {best}",
        f"Weakest growth culture: {worst}",
        "",
        "Final Variant Summary",
        "---------------------",
    ]

    for _, row in phase2_summary.iterrows():
        report_lines.extend([
            f"{row['culture']}:",
            f"Predicted next count: {int(row['predicted_next_count'])}",
            f"Harvest window: {row['harvest_window']}",
            f"Suspicious drops/jumps: {int(row['suspicious_events'])}",
            "",
        ])

    (OUTPUT_DIR / "phase3_report.txt").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )

    print(f"All phases complete. Outputs saved to {OUTPUT_DIR}.")


if __name__ == "__main__":
    main()
